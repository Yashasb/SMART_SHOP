package com.shopsmart.controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.shopsmart.dao.UserDao;
import com.shopsmart.model.CART;
import com.shopsmart.model.ITEM;
import com.shopsmart.model.LOGIN;
import com.shopsmart.model.SEARCH;
import com.shopsmart.model.SELLER;
import com.shopsmart.model.USERS;









@Controller
public class LOGIN_REGISTER {

	@Autowired
	private UserDao userDao;
	
	@RequestMapping("/login")
	public ModelAndView login() {
		//System.out.println(login.getEmailId());
		String message="";
		return new ModelAndView("login", "message", message);
	}
	@RequestMapping("/register")
	public ModelAndView register(@ModelAttribute("USERS") USERS user) {
 
		String message="REGISTER SCREEN";
		return new ModelAndView("register", "message", message);
	}
	
	@RequestMapping("/forgotpassword")
	public ModelAndView ResetPassword() {
 
		String message="RESET SCREEN";
		return new ModelAndView("forgotpassword", "message", message);
	}
	@RequestMapping("/createAccount")
	public ModelAndView CreateAccount(@ModelAttribute("USERS") USERS user) {
		System.out.println(user.getEmailId()); 
		userDao.register(user);
		String message=user.getFirstName();
		return new ModelAndView("home", "message", message);
	}
	USERS user2;
	@RequestMapping("/homepage")
	public ModelAndView homepage(@ModelAttribute("LOGIN") LOGIN login,@ModelAttribute("USERS") USERS user){
		 
		user2=userDao.validateUser(login);
		if(user2!=null){
			System.out.println(user2.getFirstName());
			String username=user2.getFirstName();
			
			List<ITEM> items= userDao.getItemList();
			System.out.println(items.get(0).getProductName());
			ModelAndView model=new ModelAndView("home", "username", username);
			//ITEM item=new ITEM();
			//item.setBrand("bold");
			List item=new ArrayList();
			item.add("hello");
			model.addObject("petsData",userDao.getItemList());
			
			return model;
		}
		else{
			String message="Invalid username/password";
			return new ModelAndView("login", "message", message);
		}
        
	}
	@RequestMapping("/productdetails")
	public ModelAndView ProductDetails() {
 
		String message="HOMEPAGE";
		return new ModelAndView("productdetails", "message", message);
	}
	@RequestMapping("/shoppingcart")
	public ModelAndView ShoppingCart(@ModelAttribute("ADDCART") CART cart) {
        
		System.out.println("testing"+cart.getProductId());
		System.out.println("testing"+ user2.getEmailId());
		userDao.addToCart(cart,user2.getEmailId());
		String message="Shopping Cart";
		
		List<ITEM> cartitems= userDao.getCartItemList(user2.getEmailId());
		System.out.println("size" +cartitems.size());
		ModelAndView model=new ModelAndView("shoppingcart", "items", cartitems);
		model.addObject("cartitems",cartitems);
		return model;
	}
	
	@RequestMapping("/conditions")
	public ModelAndView conditions() {
 
		String message="conditions";
		return new ModelAndView("conditions", "message", message);
	}
	
	@RequestMapping("/privacy")
	public ModelAndView privacy() {
 
		String message="privacy";
		return new ModelAndView("privacy", "message", message);
	}
	
	@RequestMapping("/copyright")
	public ModelAndView copyright() {
 
		String message="copyright";
		return new ModelAndView("copyright", "message", message);
	}
	@RequestMapping("/HelpContact")
	public ModelAndView HelpContact() {
 
		String message="HelpContact";
		return new ModelAndView("HelpContact", "message", message);
	}
	@RequestMapping("/sellerPage")
	public ModelAndView seller() {
 
		String message="HelpContact";
		return new ModelAndView("sellerPage", "message", message);
	}
	@RequestMapping("/cartAndPayment")
	public ModelAndView payment() {
 
		String message="HelpContact";
		return new ModelAndView("cartAndPayment", "message", message);
	}
	@RequestMapping("/finalpage")
	public ModelAndView finalpage() {
 
		String message="Your package will arrive within 7 business days";
		return new ModelAndView("finalpage", "message", message);
	}
	@RequestMapping("/sellerPageConfirm")
	public ModelAndView sellerPageConfirm(@ModelAttribute("SELLER") SELLER Seller) {
 
		userDao.Sell_item(Seller);
		String message="sellerPageConfirm";
		return new ModelAndView("productdetails", "message", message);
	}
	
	@RequestMapping("/searchItems")
	public ModelAndView searchItems(@ModelAttribute("SEARCH") SEARCH Search ) {
 
		
		String message="SearchItems";
		System.out.println(Search.getProductName());
		List<ITEM> items= userDao.getSearchItemList(Search);
		System.out.println(items.get(0).getProductName());
		ModelAndView model=new ModelAndView("home", "petsData", items);
		return model;
	}
	
	

}
