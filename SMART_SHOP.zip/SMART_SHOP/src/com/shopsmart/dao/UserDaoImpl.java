package com.shopsmart.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;






import javax.sql.DataSource;
import javax.sql.RowSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.shopsmart.*;
import com.shopsmart.model.CART;
import com.shopsmart.model.ITEM;
import com.shopsmart.model.LOGIN;
import com.shopsmart.model.SEARCH;
import com.shopsmart.model.SELLER;
import com.shopsmart.model.USERS;





public class UserDaoImpl implements UserDao {



  @Autowired

  DataSource datasource;



  @Autowired

  JdbcTemplate jdbcTemplate;



  public void register(USERS user) {



    String sql = "insert into users_details values(?,?,?,?,?)";



    jdbcTemplate.update(sql, new Object[] { user.getFirstName(),

    user.getLastName(), user.getPhoneNo(), user.getEmailId(), user.getPassword() });

    }



    public USERS validateUser(LOGIN login) {



    String sql = "select * from users_details where emailid='" + login.getEmailId() + "' and password='" + login.getPassword()

    + "'";



    List<USERS> users = jdbcTemplate.query(sql, new UserMapper());



    return users.size() > 0 ? users.get(0) : null;

    }



  

public List<ITEM> getItemList(){
	
	String sql= "Select * from items";
	
	List<ITEM> items = jdbcTemplate.query(sql, new ITEMMapper());



    return items;

	
}

public List<ITEM> getSearchItemList(SEARCH Search){
	
	String sql= "Select * from items where productname like '"+ Search.getProductName() +"'" ;
	
	List<ITEM> items = jdbcTemplate.query(sql, new ITEMMapper());



    return items;

	
}



  class UserMapper implements RowMapper<USERS> {



  public USERS mapRow(ResultSet rs, int arg1) throws SQLException {

    USERS user = new USERS();



    user.setFirstName(rs.getString("firstname"));

    user.setPassword(rs.getString("password"));

    user.setLastName(rs.getString("lastname"));

    user.setEmailId(rs.getString("emailid"));

    user.setPhoneNo(rs.getString("phone"));

    

    return user;

  }

}
  
  class ITEMMapper implements RowMapper<ITEM> {



	  public ITEM mapRow(ResultSet rs, int arg1) throws SQLException {

	    ITEM item = new ITEM();



	    item.setProductName(rs.getString("productname"));

	    item.setDescription(rs.getString("description"));
	    
	    item.setPrice(rs.getString("price"));
	    
	    item.setDepartment(rs.getString("department"));
	    
	    item.setBrand(rs.getString("brand"));
	    
	    item.setProductId(rs.getInt("productid"));

	    return item;

	  }

	}
  
  public void Sell_item(SELLER seller) {



	    String sql = "insert into shopsmart.items(productname,description,price,department,brand)  values(?,?,?,?,?)";



	    jdbcTemplate.update(sql, new Object[] { seller.getProductName(),

	    seller.getDescription(), seller.getPrice(), seller.getDepartment(), seller.getBrand() });

	    }
  
  public void addToCart(CART cart, String userid) {

String sql1="Select * From items where productid='" + cart.getProductId() + "'";

SqlRowSet rs=jdbcTemplate.queryForRowSet(sql1);


String sql2 ="insert into shopsmart.Cart(productid,productname,description,price,department,brand,userid)  values(?,?,?,?,?,?,?)";


System.out.println(rs);
if (rs.next()) {
	jdbcTemplate.update(sql2, new Object[] { cart.getProductId(),

    	    rs.getString("productname"), rs.getString("description"), rs.getInt("price"), rs.getString("department"),rs.getString("brand"),userid});

}
	    
	    }



@Override
public List<ITEM> getCartItemList(String userid) {
	// TODO Auto-generated method stub
String sql= "Select * from cart where userid='" + userid + "'";
	
	List<ITEM> items = jdbcTemplate.query(sql, new ITEMMapper());



    return items;
}
}
