package com.shopsmart.dao;

import java.util.List;

import com.shopsmart.model.CART;
import com.shopsmart.model.ITEM;
import com.shopsmart.model.LOGIN;
import com.shopsmart.model.SEARCH;
import com.shopsmart.model.SELLER;
import com.shopsmart.model.USERS;

public interface UserDao {



	  void register(USERS user);



	  USERS validateUser(LOGIN login);
	  
	  public List<ITEM> getItemList();
	  
	  public void Sell_item(SELLER seller);
	  
	  public List<ITEM> getSearchItemList(SEARCH Search);
	  
	  public void addToCart(CART cart, String userid);



	List<ITEM> getCartItemList(String userid);

	}
